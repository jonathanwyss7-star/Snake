import tkinter as tk
import snake
import apple
from time import sleep
import window as wd



root = tk.Tk()

WINDOW_SIZE = ['900', '900']


window = wd.Window(WINDOW_SIZE)


# window.MakeMenu(root)



window.MakeGameWindow(root, WINDOW_SIZE)

root.mainloop()





