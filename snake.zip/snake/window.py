import tkinter as tk
from snake import Snake
from apple import Apple


class Window:
    def __init__(self, WINDOW_SIZE):
        self.size = WINDOW_SIZE

    def MakeGameWindow(self, root, WINDOW_SIZE):
        root["bg"] = "green"
        root.title("Snake")
        canvas = tk.Canvas(root, width=WINDOW_SIZE[0], height=WINDOW_SIZE[1], bg='SpringGreen4')
        canvas.pack(anchor=tk.CENTER, expand=True)
        snake = Snake(WINDOW_SIZE)
        self.CreateSnake(root, WINDOW_SIZE, snake)
        self.CreateApple(root, WINDOW_SIZE)
        canvas.focus_set()  # ensure canvas receives key events
        canvas.bind('<Left>', lambda event: snake.goLeft())
        canvas.bind('<Right>', lambda event: snake.goRight())
        canvas.bind('<Up>', lambda event: snake.goUp())
        canvas.bind('<Down>', lambda event: snake.goDown())

        

    
    def CreateSnake(self, root, WINDOW_SIZE, snake):
        
        snakeWidget = tk.Canvas(root, width=snake.width, height=snake.length, bg=snake.color)
        snakeWidget.place(x=snake.position[0], y=snake.position[1])
        snake.Move(root, snakeWidget)

    def CreateApple(self, root, WINDOW_SIZE):
        apple = Apple(WINDOW_SIZE)
        appleWidget = tk.Canvas(root, width=apple.width, height=apple.length, bg=apple.color)
        appleWidget.place(x=apple.position[0], y=apple.position[1])

