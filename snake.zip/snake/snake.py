class Snake:
    def __init__(self, WINDOW_SIZE):
        self.color = "RoyalBlue4"
        self.position = [10, int(WINDOW_SIZE[1])/2]
        self.direction = "right"
        self.width = 20
        self.length = 20

    def Move(self, root, snakeWidget):
        if self.direction == "left":
            self.position[0] -= 30
        if self.direction == "right":
            self.position[0] += 30
        if self.direction == "up":
            self.position[1] -= 30
        if self.direction == "down":
            self.position[1] += 30
        snakeWidget.place(x=self.position[0], y=self.position[1])
        root.after(1000, lambda : self.Move(root, snakeWidget)) 
        
    def goLeft(self):
        self.direction = "left"
    
    def goRight(self):
        self.direction = "right"

    def goUp(self):
        self.direction = "up"
    
    def goDown (self):
        self.direction = "down"


