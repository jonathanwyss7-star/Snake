import random 

class Apple():
    def __init__(self, WINDOW_SIZE):
        self.color = "tomato2"
        self.length, self.width = 20, 20
        self.position = [random.randint(0,int(WINDOW_SIZE[0])), random.randint(0,int(WINDOW_SIZE[1]))]

        